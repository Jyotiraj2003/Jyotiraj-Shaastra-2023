import React from 'react'
import './style.css'
export const Footer = () => {
  let footerStyle={
    position:"relative",
    top:"90vh",
    width:"100%",
    border:"2px solid red"
  }
  return (
    <footer className="bg-dark text-light py-5" style={footerStyle}>
      <p className="text-center">
      Copyright &copy; My TodosList.com
      </p>
    </footer>
  )
}
